# LIA (v0.1)

Android voice + chat assistant. Kotlin, Jetpack Compose, OkHttp, DataStore.

## What it does
- **Voice:** Gemini Live over WebSocket. Mic is 16 kHz PCM; replies play at 24 kHz. Runs as a foreground service with a visible notification and a Stop button.
- **Text chat:** Groq chat completions (default model `llama-3.3-70b-versatile`).
- **Tools (voice):** date/time, alarm, timer, Google Maps directions, web search, open URL, open an installed app by name, open the dialer or an SMS draft (the user always taps call/send).
- **Settings:** Gemini and Groq keys with a "Check key" button that shows the real error, assistant name, 10 personalities (+ custom), voice, and model names.

## Not in v0.1
Voice rooms, Forge website builder, keyboard, sketch, Firebase login, ElevenLabs TTS. These need a backend or extra system permissions. Add them later one by one.

## Build on GitHub (no local setup needed)
1. Create a new GitHub repository (empty).
2. Unzip this folder and push everything:
   ```
   git init
   git add .
   git commit -m "LIA v0.1"
   git branch -M main
   git remote add origin https://github.com/YOUR_NAME/YOUR_REPO.git
   git push -u origin main
   ```
3. Open the **Actions** tab. The "Build APK" workflow runs. When it finishes, download `lia-debug-apk` from the run's Artifacts and install it on your phone (allow installs from unknown sources).

## Things to check on first build
- This project was written without a compiler available. If the workflow fails, open the log, copy the first `e:` error line and send it back. Most fixes are one line.
- Gemini Live model names change. If voice does not connect, set a different model in Settings → Gemini Live model (for example `gemini-2.0-flash-live-001`).
- Keys are stored in DataStore on the device. They are not encrypted in v0.1.
- Android limits starting screens from a background service. Tools that open a screen work most reliably while the app is open.

## Change the package name
Replace `com.example.lia` in `app/build.gradle.kts`, the manifest, and the Kotlin package lines before your first push.
