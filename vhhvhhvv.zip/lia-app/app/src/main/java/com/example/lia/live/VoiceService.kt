package com.example.lia.live

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.lia.MainActivity
import com.example.lia.data.ChatMsg
import com.example.lia.data.ChatStore
import com.example.lia.data.SettingsStore
import com.example.lia.prompt.Persona
import com.example.lia.tools.ToolRunner
import com.example.lia.tools.Tools
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject

class VoiceService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var live: GeminiLive? = null
    private var mic: MicRecorder? = null
    private val speaker = PcmSpeaker()
    private val pendingUser = StringBuilder()
    private val pendingAssistant = StringBuilder()
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (VoiceBus.running.value) return START_NOT_STICKY

        stopping = false
        createChannel()
        ServiceCompat.startForeground(
            this,
            NOTIF_ID,
            notification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
        )
        VoiceBus.set(true, "Connecting...")
        scope.launch { connect() }
        return START_NOT_STICKY
    }

    private suspend fun connect() {
        val s = SettingsStore(this).settings.first()
        if (s.geminiKey.isBlank()) {
            fail("Add your Gemini key in Settings first.")
            return
        }
        val session = GeminiLive(object : GeminiLive.Listener {
            override fun onReady() {
                speaker.start()
                val m = MicRecorder(scope) { chunk -> live?.sendAudio(chunk) }
                mic = m
                val ok = m.start()
                VoiceBus.set(true, if (ok) "Listening" else "Microphone could not start")
            }

            override fun onAudio(pcm: ByteArray) {
                speaker.write(pcm)
            }

            override fun onInputTranscript(text: String) {
                pendingUser.append(text)
            }

            override fun onOutputTranscript(text: String) {
                pendingAssistant.append(text)
            }

            override fun onTurnComplete() {
                commitTurn()
            }

            override fun onInterrupted() {
                speaker.flush()
                commitTurn()
            }

            override fun onToolCall(id: String, name: String, args: JsonObject) {
                val result = ToolRunner.run(this@VoiceService, name, args)
                ChatStore.add(ChatMsg("tool", "$name: $result"))
                live?.sendToolResult(id, name, result)
            }

            override fun onError(message: String) {
                ChatStore.add(ChatMsg("error", message))
                VoiceBus.set(true, "Error: $message")
            }

            override fun onClosed() {
                shutdown()
            }
        })
        live = session
        VoiceBus.live = session
        session.connect(
            apiKey = s.geminiKey,
            model = s.liveModel,
            system = Persona.systemPrompt(s),
            voice = s.voiceName,
            tools = Tools.declarations(),
        )
    }

    private fun commitTurn() {
        val u = pendingUser.toString().trim()
        val a = pendingAssistant.toString().trim()
        pendingUser.clear()
        pendingAssistant.clear()
        if (u.isNotEmpty()) ChatStore.add(ChatMsg("user", u))
        if (a.isNotEmpty()) ChatStore.add(ChatMsg("assistant", a))
    }

    private fun fail(message: String) {
        ChatStore.add(ChatMsg("error", message))
        shutdown()
    }

    private fun shutdown() {
        if (stopping) return
        stopping = true
        mic?.stop()
        mic = null
        speaker.stop()
        live?.close()
        live = null
        VoiceBus.live = null
        VoiceBus.set(false, "")
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        scope.cancel()
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Voice assistant", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("LIA is listening")
            .setContentText("Voice assistant is running")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.example.lia.STOP_VOICE"
        private const val CHANNEL_ID = "lia_voice"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, VoiceService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, VoiceService::class.java).setAction(ACTION_STOP))
        }
    }
}
