package com.example.lia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.lia.ui.LiaRoot
import com.example.lia.ui.LiaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LiaTheme {
                LiaRoot()
            }
        }
    }
}
