package com.example.lia

import android.app.Application
import com.example.lia.data.ChatStore

class LiaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ChatStore.init(this)
    }
}
