package com.example.lia.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.lia.data.AppSettings
import com.example.lia.data.ChatMsg
import com.example.lia.live.VoiceService
import com.example.lia.net.KeyCheck
import com.example.lia.prompt.Persona
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiaRoot(vm: AppVm = viewModel()) {
    val ctx = LocalContext.current
    val voiceOn by vm.voiceOn.collectAsState()
    var showSettings by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted[Manifest.permission.RECORD_AUDIO] == true) VoiceService.start(ctx)
    }

    val onVoice: () -> Unit = {
        when {
            voiceOn -> VoiceService.stop(ctx)
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == 0 -> VoiceService.start(ctx)
            else -> permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (showSettings) "Settings" else "LIA") },
                actions = {
                    TextButton(onClick = { showSettings = !showSettings }) {
                        Text(if (showSettings) "Done" else "Settings")
                    }
                },
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (showSettings) SettingsScreen(vm) else HomeScreen(vm, onVoice)
        }
    }
}

@Composable
fun HomeScreen(vm: AppVm, onVoice: () -> Unit) {
    val messages by vm.messages.collectAsState()
    val voiceOn by vm.voiceOn.collectAsState()
    val status by vm.status.collectAsState()
    val busy by vm.busy.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Button(onClick = onVoice, modifier = Modifier.fillMaxWidth()) {
            Text(if (voiceOn) "Stop voice" else "Start voice")
        }
        if (status.isNotBlank()) {
            Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
        }
        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth()) {
            items(messages) { m -> MessageRow(m) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message") },
                maxLines = 4,
            )
            Spacer(Modifier.width(8.dp))
            Button(
                enabled = input.isNotBlank() && !busy,
                onClick = {
                    vm.sendText(input)
                    input = ""
                },
            ) { Text("Send") }
        }
    }
}

@Composable
fun MessageRow(m: ChatMsg) {
    val mine = m.role == "user"
    Column(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalAlignment = if (mine) Alignment.End else Alignment.Start,
    ) {
        Text(m.role.uppercase(), style = MaterialTheme.typography.labelSmall)
        Surface(
            color = if (mine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            shape = MaterialTheme.shapes.medium,
        ) {
            Text(m.text, modifier = Modifier.padding(10.dp))
        }
    }
}

@Composable
fun SettingsScreen(vm: AppVm) {
    val saved by vm.settings.collectAsState()
    val scope = rememberCoroutineScope()

    var geminiKey by remember { mutableStateOf(saved.geminiKey) }
    var groqKey by remember { mutableStateOf(saved.groqKey) }
    var geminiStatus by remember { mutableStateOf("") }
    var groqStatus by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(saved.assistantName) }
    var personality by remember { mutableStateOf(saved.personality) }
    var customInstruction by remember { mutableStateOf(saved.customInstruction) }
    var voice by remember { mutableStateOf(saved.voiceName) }
    var liveModel by remember { mutableStateOf(saved.liveModel) }
    var groqModel by remember { mutableStateOf(saved.groqModel) }
    var savedNote by remember { mutableStateOf("") }

    val voices = listOf("Aoede", "Callirrhoe", "Kore", "Leda", "Sulafat", "Zephyr")

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        SectionTitle("API keys")
        OutlinedTextField(
            value = geminiKey,
            onValueChange = { geminiKey = it },
            label = { Text("Gemini API key (voice)") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Button(onClick = {
            scope.launch {
                geminiStatus = "Checking..."
                geminiStatus = KeyCheck.gemini(geminiKey)
            }
        }) { Text("Check Gemini key") }
        if (geminiStatus.isNotBlank()) Text(geminiStatus, style = MaterialTheme.typography.bodySmall)

        OutlinedTextField(
            value = groqKey,
            onValueChange = { groqKey = it },
            label = { Text("Groq API key (text chat)") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Button(onClick = {
            scope.launch {
                groqStatus = "Checking..."
                groqStatus = KeyCheck.groq(groqKey)
            }
        }) { Text("Check Groq key") }
        if (groqStatus.isNotBlank()) Text(groqStatus, style = MaterialTheme.typography.bodySmall)

        SectionTitle("Assistant")
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Assistant name") },
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Personality", style = MaterialTheme.typography.titleSmall)
        Persona.presets.forEach { p ->
            OptionRow(selected = personality == p.id, title = p.title, subtitle = p.blurb) {
                personality = p.id
            }
        }
        if (personality == "custom") {
            OutlinedTextField(
                value = customInstruction,
                onValueChange = { customInstruction = it },
                label = { Text("Your style instruction") },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        SectionTitle("Voice")
        voices.forEach { v ->
            OptionRow(selected = voice == v, title = v, subtitle = "") { voice = v }
        }
        OutlinedTextField(
            value = liveModel,
            onValueChange = { liveModel = it },
            label = { Text("Gemini Live model") },
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = groqModel,
            onValueChange = { groqModel = it },
            label = { Text("Groq chat model") },
            modifier = Modifier.fillMaxWidth(),
        )

        Button(
            onClick = {
                vm.save(
                    AppSettings(
                        geminiKey = geminiKey,
                        groqKey = groqKey,
                        assistantName = name,
                        personality = personality,
                        customInstruction = customInstruction,
                        voiceName = voice,
                        liveModel = liveModel,
                        groqModel = groqModel,
                    )
                )
                savedNote = "Saved. Changes apply to the next voice session."
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Save") }
        if (savedNote.isNotBlank()) Text(savedNote, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
}

@Composable
private fun OptionRow(selected: Boolean, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Column(Modifier.padding(start = 8.dp)) {
            Text(title)
            if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}
