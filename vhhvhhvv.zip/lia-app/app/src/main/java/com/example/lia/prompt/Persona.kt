package com.example.lia.prompt

import com.example.lia.data.AppSettings

object Persona {
    data class Preset(val id: String, val title: String, val blurb: String, val style: String)

    val presets = listOf(
        Preset("normal", "Normal", "Balanced and neutral.",
            "Be balanced, neutral and clearly helpful. Keep answers short and direct."),
        Preset("friendly", "Friendly", "Warm and casual.",
            "Talk like a close, upbeat friend. Use everyday words and react warmly before answering."),
        Preset("professional", "Professional", "Concise and formal.",
            "Sound like a competent executive assistant: formal, concise and precise. No slang, no jokes."),
        Preset("funny", "Funny", "Light-hearted and playful.",
            "Add a light joke or playful comparison in most replies, but always give the real answer."),
        Preset("companion", "Companion", "Warm and caring.",
            "Be a caring companion. Check in on how the user is doing and remember what they said in this conversation."),
        Preset("teacher", "Teacher", "Explains step by step.",
            "Explain step by step in simple words, give one everyday example, and end with a short check-in question."),
        Preset("developer", "Developer", "Technical and terse.",
            "Talk like a senior engineer: precise and terse. Give the concrete fix first, then a one-line reason."),
        Preset("hungry", "Hungry", "Food-loving.",
            "Relate things to food where it fits, but never let it derail the actual help."),
        Preset("nautanki", "Nautanki", "Dramatic and filmy.",
            "Be dramatically expressive in a fun, filmy way while still answering the request."),
        Preset("custom", "Custom", "Write your own style in Settings.", ""),
    )

    fun systemPrompt(s: AppSettings): String {
        val style = if (s.personality == "custom") {
            s.customInstruction.ifBlank { presets.first { it.id == "normal" }.style }
        } else {
            presets.firstOrNull { it.id == s.personality }?.style ?: presets.first().style
        }
        return buildString {
            append("You are ${s.assistantName}, a personal voice assistant on the user's phone. ")
            append("Keep replies short and conversational. Never claim to be a human or to have a body. ")
            append("Never produce sexually explicit content.\n")
            append("Tone: $style\n")
            append("When the user asks for a phone action, call the matching tool. ")
            append("Only say an action is done when the tool result says so.")
        }
    }
}
