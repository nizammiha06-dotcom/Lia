package com.example.lia.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LiaDark = darkColorScheme(
    background = Color(0xFF070816),
    surface = Color(0xFF14112A),
    surfaceVariant = Color(0xFF2A1F4D),
    primary = Color(0xFF8B5CF6),
    onPrimary = Color.White,
    secondary = Color(0xFF3FE0A8),
    onBackground = Color(0xFFEEE9FF),
    onSurface = Color(0xFFEEE9FF),
    onSurfaceVariant = Color(0xFFCFC7F5),
)

@Composable
fun LiaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LiaDark, content = content)
}
