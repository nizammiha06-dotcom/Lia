package com.example.lia.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File

@Serializable
data class ChatMsg(
    val role: String, // "user", "assistant", "tool", "error"
    val text: String,
    val time: Long = System.currentTimeMillis(),
)

object ChatStore {
    private val _messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val messages: StateFlow<List<ChatMsg>> = _messages.asStateFlow()

    private val json = Json { ignoreUnknownKeys = true }
    private val listSer = ListSerializer(ChatMsg.serializer())
    private var file: File? = null

    fun init(context: Context) {
        val f = File(context.filesDir, "chat.json")
        file = f
        runCatching {
            if (f.exists()) _messages.value = json.decodeFromString(listSer, f.readText())
        }
    }

    fun add(msg: ChatMsg) {
        _messages.update { it + msg }
        save()
    }

    fun clear() {
        _messages.value = emptyList()
        save()
    }

    @Synchronized
    private fun save() {
        runCatching { file?.writeText(json.encodeToString(listSer, _messages.value)) }
    }
}
