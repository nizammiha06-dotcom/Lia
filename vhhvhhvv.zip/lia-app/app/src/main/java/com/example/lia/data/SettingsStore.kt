package com.example.lia.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

const val DEFAULT_LIVE_MODEL = "gemini-2.5-flash-native-audio-preview-12-2025"
const val DEFAULT_GROQ_MODEL = "llama-3.3-70b-versatile"

data class AppSettings(
    val geminiKey: String = "",
    val groqKey: String = "",
    val assistantName: String = "Lia",
    val personality: String = "normal",
    val customInstruction: String = "",
    val voiceName: String = "Kore",
    val liveModel: String = DEFAULT_LIVE_MODEL,
    val groqModel: String = DEFAULT_GROQ_MODEL,
)

private val Context.settingsDataStore by preferencesDataStore(name = "lia_settings")

private object Keys {
    val gemini = stringPreferencesKey("gemini_key")
    val groq = stringPreferencesKey("groq_key")
    val name = stringPreferencesKey("assistant_name")
    val personality = stringPreferencesKey("personality")
    val custom = stringPreferencesKey("custom_instruction")
    val voice = stringPreferencesKey("voice_name")
    val liveModel = stringPreferencesKey("live_model")
    val groqModel = stringPreferencesKey("groq_model")
}

private fun Preferences.toSettings() = AppSettings(
    geminiKey = this[Keys.gemini] ?: "",
    groqKey = this[Keys.groq] ?: "",
    assistantName = this[Keys.name] ?: "Lia",
    personality = this[Keys.personality] ?: "normal",
    customInstruction = this[Keys.custom] ?: "",
    voiceName = this[Keys.voice] ?: "Kore",
    liveModel = this[Keys.liveModel] ?: DEFAULT_LIVE_MODEL,
    groqModel = this[Keys.groqModel] ?: DEFAULT_GROQ_MODEL,
)

class SettingsStore(private val context: Context) {
    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { it.toSettings() }

    suspend fun save(s: AppSettings) {
        context.settingsDataStore.edit { p ->
            p[Keys.gemini] = s.geminiKey.trim()
            p[Keys.groq] = s.groqKey.trim()
            p[Keys.name] = s.assistantName.trim().ifEmpty { "Lia" }
            p[Keys.personality] = s.personality
            p[Keys.custom] = s.customInstruction
            p[Keys.voice] = s.voiceName
            p[Keys.liveModel] = s.liveModel.trim().ifEmpty { DEFAULT_LIVE_MODEL }
            p[Keys.groqModel] = s.groqModel.trim().ifEmpty { DEFAULT_GROQ_MODEL }
        }
    }
}
