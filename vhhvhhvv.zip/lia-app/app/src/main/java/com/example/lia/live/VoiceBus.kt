package com.example.lia.live

import kotlinx.coroutines.flow.MutableStateFlow

/** Shared voice state so the UI can show and control the running voice session. */
object VoiceBus {
    val running = MutableStateFlow(false)
    val status = MutableStateFlow("")

    @Volatile
    var live: GeminiLive? = null

    fun set(on: Boolean, text: String) {
        running.value = on
        status.value = text
    }
}
