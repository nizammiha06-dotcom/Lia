package com.example.lia.live

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.util.Base64
import java.util.concurrent.TimeUnit

/**
 * Minimal client for the Gemini Live (BidiGenerateContent) WebSocket API.
 * Audio in: 16 kHz PCM16 mono. Audio out: PCM16 mono at 24 kHz.
 */
class GeminiLive(private val listener: Listener) {

    interface Listener {
        fun onReady()
        fun onAudio(pcm: ByteArray)
        fun onInputTranscript(text: String)
        fun onOutputTranscript(text: String)
        fun onTurnComplete()
        fun onInterrupted()
        fun onToolCall(id: String, name: String, args: JsonObject)
        fun onError(message: String)
        fun onClosed()
    }

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null

    @Volatile
    var ready: Boolean = false
        private set

    fun connect(apiKey: String, model: String, system: String, voice: String, tools: JsonArray) {
        val fullModel = if (model.startsWith("models/")) model else "models/$model"
        val setup = buildJsonObject {
            putJsonObject("setup") {
                put("model", fullModel)
                putJsonObject("generationConfig") {
                    putJsonArray("responseModalities") { add(JsonPrimitive("AUDIO")) }
                    putJsonObject("speechConfig") {
                        putJsonObject("voiceConfig") {
                            putJsonObject("prebuiltVoiceConfig") {
                                put("voiceName", voice)
                            }
                        }
                    }
                }
                putJsonObject("systemInstruction") {
                    putJsonArray("parts") {
                        addJsonObject { put("text", system) }
                    }
                }
                putJsonObject("inputAudioTranscription") {}
                putJsonObject("outputAudioTranscription") {}
                put("tools", tools)
            }
        }

        val request = Request.Builder()
            .url(URL)
            .header("x-goog-api-key", apiKey.trim())
            .build()

        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(setup.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handle(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                handle(bytes.utf8())
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val code = response?.code?.let { " HTTP $it" } ?: ""
                listener.onError("Live connection failed$code: ${t.message ?: "unknown error"}")
                listener.onClosed()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                listener.onClosed()
            }
        })
    }

    private fun handle(raw: String) {
        val root = runCatching { Json.parseToJsonElement(raw).jsonObject }.getOrNull() ?: return

        if (root.containsKey("setupComplete")) {
            ready = true
            listener.onReady()
            return
        }

        root["serverContent"]?.jsonObject?.let { sc ->
            sc["modelTurn"]?.jsonObject?.get("parts")?.jsonArray?.forEach { part ->
                val data = part.jsonObject["inlineData"]?.jsonObject?.get("data")?.jsonPrimitive?.content
                if (data != null) listener.onAudio(Base64.getDecoder().decode(data))
            }
            sc["inputTranscription"]?.jsonObject?.get("text")?.jsonPrimitive?.content?.let {
                listener.onInputTranscript(it)
            }
            sc["outputTranscription"]?.jsonObject?.get("text")?.jsonPrimitive?.content?.let {
                listener.onOutputTranscript(it)
            }
            if (sc["interrupted"]?.jsonPrimitive?.booleanOrNull == true) listener.onInterrupted()
            if (sc["turnComplete"]?.jsonPrimitive?.booleanOrNull == true) listener.onTurnComplete()
        }

        root["toolCall"]?.jsonObject?.get("functionCalls")?.jsonArray?.forEach { fc ->
            val o = fc.jsonObject
            val id = o["id"]?.jsonPrimitive?.content ?: return@forEach
            val name = o["name"]?.jsonPrimitive?.content ?: return@forEach
            listener.onToolCall(id, name, o["args"]?.jsonObject ?: JsonObject(emptyMap()))
        }

        root["error"]?.let { listener.onError(it.toString()) }
    }

    fun sendAudio(pcm: ByteArray) {
        if (!ready) return
        val msg = buildJsonObject {
            putJsonObject("realtimeInput") {
                putJsonArray("mediaChunks") {
                    addJsonObject {
                        put("mimeType", "audio/pcm;rate=16000")
                        put("data", Base64.getEncoder().encodeToString(pcm))
                    }
                }
            }
        }
        socket?.send(msg.toString())
    }

    fun sendText(text: String) {
        val msg = buildJsonObject {
            putJsonObject("clientContent") {
                putJsonArray("turns") {
                    addJsonObject {
                        put("role", "user")
                        putJsonArray("parts") {
                            addJsonObject { put("text", text) }
                        }
                    }
                }
                put("turnComplete", true)
            }
        }
        socket?.send(msg.toString())
    }

    fun sendToolResult(id: String, name: String, result: String) {
        val msg = buildJsonObject {
            putJsonObject("toolResponse") {
                putJsonArray("functionResponses") {
                    addJsonObject {
                        put("id", id)
                        put("name", name)
                        putJsonObject("response") { put("result", result) }
                    }
                }
            }
        }
        socket?.send(msg.toString())
    }

    fun close() {
        socket?.close(1000, "bye")
        socket = null
        ready = false
    }

    companion object {
        private const val URL =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
    }
}
