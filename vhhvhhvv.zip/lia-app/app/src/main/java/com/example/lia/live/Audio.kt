package com.example.lia.live

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

class MicRecorder(private val scope: CoroutineScope, private val onChunk: (ByteArray) -> Unit) {
    private var job: Job? = null

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(min, CHUNK * 4),
            )
        } catch (e: SecurityException) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        rec.startRecording()
        job = scope.launch {
            val buf = ByteArray(CHUNK)
            try {
                while (isActive) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n > 0) onChunk(buf.copyOf(n)) else if (n < 0) break
                }
            } finally {
                runCatching { rec.stop() }
                rec.release()
            }
        }
        return true
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    companion object {
        const val RATE = 16000
        const val CHUNK = 3200 // 100 ms of 16 kHz mono PCM16
    }
}

class PcmSpeaker {
    private var track: AudioTrack? = null
    private val exec = Executors.newSingleThreadExecutor()

    fun start() {
        if (track != null) return
        val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(min, RATE))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
            .also { it.play() }
    }

    fun write(pcm: ByteArray) {
        exec.execute { track?.write(pcm, 0, pcm.size) }
    }

    /** Drop queued audio, used when the user interrupts the assistant. */
    fun flush() {
        exec.execute {
            track?.pause()
            track?.flush()
            track?.play()
        }
    }

    fun stop() {
        exec.execute {
            track?.stop()
            track?.release()
            track = null
        }
    }

    companion object {
        const val RATE = 24000
    }
}
