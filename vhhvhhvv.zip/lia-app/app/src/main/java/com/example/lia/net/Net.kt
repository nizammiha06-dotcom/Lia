package com.example.lia.net

import com.example.lia.data.ChatMsg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.addJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

private val http: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .build()

object KeyCheck {
    suspend fun gemini(key: String): String = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext "Enter a Gemini key first."
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1")
            .header("x-goog-api-key", key.trim())
            .build()
        describe("Gemini") { http.newCall(req).execute().use { it.code } }
    }

    suspend fun groq(key: String): String = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext "Enter a Groq key first."
        val req = Request.Builder()
            .url("https://api.groq.com/openai/v1/models")
            .header("Authorization", "Bearer ${key.trim()}")
            .build()
        describe("Groq") { http.newCall(req).execute().use { it.code } }
    }

    private inline fun describe(name: String, call: () -> Int): String = try {
        when (val code = call()) {
            in 200..299 -> "$name key works."
            400, 401, 403 -> "$name rejected the key (HTTP $code). Check it and save again."
            429 -> "$name quota or rate limit reached (HTTP 429). Try later or check billing."
            else -> "$name returned HTTP $code."
        }
    } catch (e: IOException) {
        "Could not reach $name. Check your internet. (${e.message})"
    }
}

object GroqChat {
    suspend fun reply(apiKey: String, model: String, system: String, history: List<ChatMsg>): String =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) error("Add a Groq key in Settings first.")
            val body = buildJsonObject {
                put("model", model)
                put("temperature", 0.7)
                putJsonArray("messages") {
                    addJsonObject {
                        put("role", "system")
                        put("content", system)
                    }
                    history.forEach { m ->
                        addJsonObject {
                            put("role", if (m.role == "user") "user" else "assistant")
                            put("content", m.text)
                        }
                    }
                }
            }
            val req = Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .header("Authorization", "Bearer ${apiKey.trim()}")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { res ->
                val text = res.body?.string().orEmpty()
                if (!res.isSuccessful) error(friendly(res.code))
                val content = Json.parseToJsonElement(text).jsonObject["choices"]
                    ?.jsonArray?.firstOrNull()?.jsonObject
                    ?.get("message")?.jsonObject
                    ?.get("content")?.jsonPrimitive?.contentOrNull
                    ?: error("Empty reply from Groq.")
                content.replace(Regex("(?s)<think>.*?</think>"), "").trim()
            }
        }

    private fun friendly(code: Int): String = when (code) {
        401, 403 -> "Groq rejected the key (HTTP $code). Check it in Settings."
        429 -> "Groq rate limit reached. Try again shortly."
        else -> "Groq error (HTTP $code)."
    }
}
