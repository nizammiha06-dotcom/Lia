package com.example.lia.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.lia.data.AppSettings
import com.example.lia.data.ChatMsg
import com.example.lia.data.ChatStore
import com.example.lia.data.SettingsStore
import com.example.lia.live.VoiceBus
import com.example.lia.net.GroqChat
import com.example.lia.prompt.Persona
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppVm(app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)

    val settings: StateFlow<AppSettings> =
        store.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())
    val messages: StateFlow<List<ChatMsg>> = ChatStore.messages
    val voiceOn: StateFlow<Boolean> = VoiceBus.running
    val status: StateFlow<String> = VoiceBus.status

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun save(s: AppSettings) {
        viewModelScope.launch { store.save(s) }
    }

    fun sendText(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        ChatStore.add(ChatMsg("user", t))

        // During a voice session, typed text goes into the same live conversation.
        val live = VoiceBus.live
        if (VoiceBus.running.value && live != null) {
            live.sendText(t)
            return
        }

        viewModelScope.launch {
            _busy.value = true
            val s = settings.value
            val history = messages.value
                .filter { it.role == "user" || it.role == "assistant" }
                .takeLast(30)
            val result = runCatching {
                GroqChat.reply(s.groqKey, s.groqModel, Persona.systemPrompt(s), history)
            }
            ChatStore.add(
                result.fold(
                    onSuccess = { ChatMsg("assistant", it) },
                    onFailure = { ChatMsg("error", it.message ?: "Something went wrong.") },
                )
            )
            _busy.value = false
        }
    }
}
