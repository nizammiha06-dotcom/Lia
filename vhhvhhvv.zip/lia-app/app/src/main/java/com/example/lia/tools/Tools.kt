package com.example.lia.tools

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Function declarations sent to Gemini Live. */
object Tools {
    private fun prop(type: String, description: String): JsonObject = buildJsonObject {
        put("type", type)
        put("description", description)
    }

    private fun fn(
        name: String,
        description: String,
        props: Map<String, JsonObject> = emptyMap(),
        required: List<String> = emptyList(),
    ): JsonObject = buildJsonObject {
        put("name", name)
        put("description", description)
        if (props.isNotEmpty()) {
            putJsonObject("parameters") {
                put("type", "OBJECT")
                putJsonObject("properties") {
                    props.forEach { (k, v) -> put(k, v) }
                }
                if (required.isNotEmpty()) {
                    putJsonArray("required") {
                        required.forEach { add(JsonPrimitive(it)) }
                    }
                }
            }
        }
    }

    fun declarations(): JsonArray {
        val list = listOf(
            fn("get_current_datetime", "Get the current date, weekday and time on the phone."),
            fn(
                "set_alarm", "Set an alarm on the phone clock.",
                mapOf(
                    "hour" to prop("INTEGER", "Hour, 0-23"),
                    "minute" to prop("INTEGER", "Minute, 0-59"),
                    "label" to prop("STRING", "Optional label"),
                ),
                listOf("hour", "minute"),
            ),
            fn(
                "set_timer", "Start a countdown timer.",
                mapOf("seconds" to prop("INTEGER", "Length in seconds")),
                listOf("seconds"),
            ),
            fn(
                "navigate_to", "Open Google Maps directions to a place or address.",
                mapOf("destination" to prop("STRING", "Place or address")),
                listOf("destination"),
            ),
            fn(
                "web_search", "Search the web in the browser.",
                mapOf("query" to prop("STRING", "What to search for")),
                listOf("query"),
            ),
            fn(
                "open_url", "Open a web link in the browser.",
                mapOf("url" to prop("STRING", "Full http or https address")),
                listOf("url"),
            ),
            fn(
                "open_app", "Open an installed app by its name.",
                mapOf("app_name" to prop("STRING", "App name as the user said it")),
                listOf("app_name"),
            ),
            fn(
                "dial_number", "Open the dialer with a phone number. The user taps call themselves.",
                mapOf("number" to prop("STRING", "Phone number")),
                listOf("number"),
            ),
            fn(
                "compose_sms", "Open the SMS composer with a message. The user taps send themselves.",
                mapOf(
                    "number" to prop("STRING", "Phone number"),
                    "message" to prop("STRING", "Message text"),
                ),
                listOf("number", "message"),
            ),
            fn("phone_status", "Read battery level and charging state."),
        )
        return buildJsonArray {
            addJsonObject {
                putJsonArray("functionDeclarations") {
                    list.forEach { add(it) }
                }
            }
        }
    }
}

/** Runs a tool call through standard Android intents. Nothing is sent or saved without the user. */
object ToolRunner {
    fun run(ctx: Context, name: String, args: JsonObject): String {
        return try {
            when (name) {
                "get_current_datetime" ->
                    SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm z", Locale.ENGLISH).format(Date())

                "set_alarm" -> launch(
                    ctx,
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, args.int("hour") ?: 7)
                        .putExtra(AlarmClock.EXTRA_MINUTES, args.int("minute") ?: 0)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, args.str("label") ?: "LIA alarm")
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                    "alarm_set",
                )

                "set_timer" -> launch(
                    ctx,
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, args.int("seconds") ?: 60)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true),
                    "timer_set",
                )

                "navigate_to" -> {
                    val q = args.str("destination") ?: return "missing_destination"
                    val maps = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(q)))
                        .setPackage("com.google.android.apps.maps")
                    val first = launch(ctx, maps, "navigation_opened")
                    if (first == "navigation_opened") first
                    else launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))), "map_opened")
                }

                "web_search" -> {
                    val q = args.str("query") ?: return "missing_query"
                    launch(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q), "search_opened")
                }

                "open_url" -> {
                    val uri = Uri.parse(args.str("url") ?: return "missing_url")
                    if (uri.scheme != "http" && uri.scheme != "https") return "invalid_url"
                    launch(ctx, Intent(Intent.ACTION_VIEW, uri), "link_opened")
                }

                "open_app" -> openApp(ctx, args.str("app_name") ?: return "missing_app_name")

                "dial_number" -> {
                    val n = args.str("number") ?: return "missing_number"
                    launch(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))), "dialer_opened")
                }

                "compose_sms" -> {
                    val n = args.str("number") ?: return "missing_number"
                    val msg = args.str("message") ?: ""
                    launch(
                        ctx,
                        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))).putExtra("sms_body", msg),
                        "composer_opened",
                    )
                }

                "phone_status" -> batteryStatus(ctx)

                else -> "unknown_tool"
            }
        } catch (e: Exception) {
            "failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun launch(ctx: Context, intent: Intent, okText: String): String {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            okText
        } catch (e: ActivityNotFoundException) {
            "no_app_found"
        }
    }

    private fun openApp(ctx: Context, wanted: String): String {
        val pm = ctx.packageManager
        val launchers = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val target = launchers.firstOrNull { it.loadLabel(pm).toString().equals(wanted, ignoreCase = true) }
            ?: launchers.firstOrNull { it.loadLabel(pm).toString().contains(wanted, ignoreCase = true) }
            ?: return "app_not_found"
        val intent = pm.getLaunchIntentForPackage(target.activityInfo.packageName)
            ?: return "app_not_launchable"
        return launch(ctx, intent, "opened")
    }

    private fun batteryStatus(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        return "battery ${pct}%, charging=$charging"
    }

    private fun JsonObject.str(key: String): String? = this[key]?.jsonPrimitive?.contentOrNull

    private fun JsonObject.int(key: String): Int? {
        val p = this[key]?.jsonPrimitive ?: return null
        return p.intOrNull ?: p.doubleOrNull?.toInt()
    }
}
